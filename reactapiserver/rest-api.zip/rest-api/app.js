const express = require ('express');
const app = express();
const morgan = require('morgan');// morgan call next function if problem occure
const bodyParser = require('body-parser');// this package use to formate json data 
const mongoose = require ('mongoose');

// Routes which should handle requests
const productRoutes = require('./api/routes/products');
const orderRoutes = require('./api/routes/orders');// this is fro route order which is in api->routes->orders.js
const userRoutes = require('./api/routes/user'); // this is new for signup

//mongoose.connect('mongodb+srv://node-shop:'+ process.env.MANGO_ATLAS_PW'@node-rest-shop-dz1fp.mongodb.net/test?retryWrites=true'
//mongoose.connect('mongodb+srv://node-shop:'+ process.env.MONGO_ATLAS_PW +'@node-rest-shop-dz1fp.mongodb.net/test?retryWrites=true',

mongoose.connect('mongodb+srv://node-shop:'+ process.env.MONGO_ATLAS_PW +'@node-rest-shop-dz1fp.mongodb.net/test?retryWrites=true',
	{ 
		useNewUrlParser: true
	}
	);
mongoose.promise =global.Promise;
// process.env.MANGO_ATLAS_PW envirnmaent variable name
app.use(morgan('dev'));
app.use(bodyParser.urlencoded({extended: false}));// urlencode true and false simple-body url data
app.use(bodyParser.json());// it show json data in good manner

app.use((req, res, next) =>{
	res.header("Access-Control-Allow_original","*"); // use API from anywhere insted of * we use domain
	res.header("Access-Control-Allow_Headers","Origin, X-requested-With, Content-Type, Accept, Authorization");

	if (req.method === 'OPTIONS') {
	req.header('Access-Control-Allow_Methods','PUT, POST, PATCH, DELETE, GET');
	return res.status(200).json({});
}
next();
});

// route for all urls
app.use('/products', productRoutes);
app.use('/orders', orderRoutes);
app.use("/user", userRoutes);

// handle all other request which not found 
app.use((req, res, next) => {
	const error = new Error('Not Found Manual ERROR');
	error.status = 404;
	next(error);
		// when we get 404 error it send to next 
});

// it will handel all error in the application
app.use((error, req, res, next) => {
	// 500 type error is used when we use database
	res.status(error.status || 500);
	res.json({
		error:{
			message:error.message
		}
	})
});

module.exports = app;